# 版本记录 Changelog

版本号采用名录发布日期（YYYY.MM.DD）。同一版本重跑生成脚本应得到逐字节一致的文件；新增/修订数据请升版本号后再归档。

## 2026.10.30 — 异名补录与命名差异判定修订

- **新增文献补录（2026-10-31，同一版本，尚未归档发布）**：按近年原始文献补录 18 个新种、4 个新亚种、3 个新属，并修订 4 处分类变动——
  - 新属：*Ekueitermes*（肠棘白蚁属）、*Spiralitermes*（螺旋白蚁属）、*Scheffrahnitermes*（谢弗拉恩白蚁属），均隶尖白蚁亚科（Apicotermitinae）；
  - 新种（18）：*Ekueitermes alerosinus*、*Spiralitermes jurupari*、*Scheffrahnitermes ubuntu*、*Chasitermes tupan*、*Pseudocapritermes novus*、*Labiocapritermes microcephalus*、*L. wayanadensis*、*Proneotermes tacicuarensis*、*Acorhinotermes murui*、*Termes incognitus*、*Isognathotermes acristatus*、*I. modicus*、*I. magniplanifrons*、*I. phallicaecalis*、*I. phalloides*、*I. rectimalatus*、*I. similifinitimus*、*Amitermes californicus*；
  - 新亚种（4）：*Isognathotermes ugandensis burundii*、*I. u. kenyae*、*I. u. malawii*、*I. u. ugandensis*（方白蚁亚科）；
  - *Isognathotermes* 属整合修订（EJT 1024, 2025）：补 5 个异名（*I. gibbifrons* → *I. bulbifrons*、*I. speciosus* → *I. finitimus*、*I. gaigei* → *I. planifrons*、*I. modestior* / *I. silvestrii* → *I. severus*）；*I. congoensis* 改注 incertae sedis；
  - *Amitermes californicus* 依 Zootaxa 5128（2022）恢复为有效种，从 *A. wheeleri* 次异名中拆出（此前按外部库对照误并）；
  - *Xiaitermes tiantaiensis* 依 Insects 17: 602（2026）降为 *X. yinxianensis* 次异名，删除其物种页；
  - 计数：分类单元记录 3068 → 3089（种 3004 → 3021、亚种 64 → 68、属 323 → 326）；尖白蚁亚科 237 → 241 种 / 68 属，方白蚁亚科 142 → 149 种、亚种 6 → 10，瘤白蚁亚科 132 → 135 种，弓白蚁亚科 193 → 194 种，白蚁亚科 106 → 107 种，象白蚁亚科 607 → 606 种，木白蚁科 479 → 480 种，鼻白蚁科 61 → 62 种；
  - 三语名录、isoptera-data.json、data/ 结构化数据（含 data/index.json 计数与文件字节数）、检索索引、sitemap、统计页、dataset/ 归档包与外部库缓存（_data/authority_links.json、_data/bsf_links.json、_data/papers.json、_data/name_issues.json）均已按新名录重算；
  - 说明：新种模式产地以原文为准；*Spiralitermes jurupari*、*Chasitermes tupan*、*Scheffrahnitermes ubuntu* 的产地仅到区域级（原文摘要未给出具体地点），待补。
  - **站点结构（同版本）**：`/list/` 由全量名录改为**名录索引**——只保留分类框架说明、搜索框、按科浏览（13 科）、支系—科两层入口（6 支系、每科在该支系下的计数）与页末 77 条参考文献；逐条名录（326 属 / 3021 种 / 68 亚种）下沉到 `/family/`、`/subfamily/`、`/genus/` 三级页面，属页列出该属全部种与亚种，科页与亚科页承担本级说明、分布图与下一级入口。科／亚科正文的英译与西译整段迁到 `/en/list/sections/`、`/es/list/sections/` 两个译文页（各 466 行），中文正文仍渲染在科页与亚科页。
  - **数据源（同版本）**：分类层级、三语科亚科正文、索引页说明块改为 `_data/taxonomy.json`、`_data/taxon_prose.json`、`_data/list_index_blocks.json` 三个数据文件；`_tools/build_list_index.py` 据此生成三语索引页与两个译文页（5 个页面，**不再手改**），`_tools/extract_taxon_data.py --check` 校验三者自洽。`build_taxonomy_data.py`、`build_search_index.py` 改从 taxonomy.json 建树，面包屑、统计页、检索结果与分布图内链一律改指 `/family|/subfamily|/genus/<id>/`，物种页正文里的「分类位置」链接同步重写；`check_site.py` 的不变量改为「三语索引页锚点同构 + 每个科/亚科/属都有页面 + 每个物种页都出现在其属页上」。
  - 固化：新增 `_tools/build_taxonomy_data.py`（只用标准库、确定性输出、支持 `--check`），从 `list.md`（当时仍是全量名录，现改读 `_data/taxonomy.json`，见下条）+ `_species/` 统一生成 `isoptera-data.json`、`data/index.json`、`data/*.json` 与三语 `stats.md`；已接入 `validate.yml` 与 `pages.yml` 的生成顺序，此后增删类群不再需要手工改这些派生产物；
  - 修复：`data/*.json` 的 `distribution` 字段此前带一个多余的右括号（如「安哥拉）」，由历史生成逻辑残留），已统一去掉；`data/index.json` 中按支系合辑存放的科（远等翅类 4 科、新等翅类除白蚁科 6 科）的 `file` 链接改为指向实际合辑文件（此前指向不存在的单科文件）；
  - 统计页：属级明细表改为固定排序（种数降序、同种数按拉丁名升序），英文版「Overview」与亚科表表头改用英文标签；三语统计页计数与名录同步；
  - 名称微调：*Isognathotermes phalloides* 中文正名由「似阳茎等颚白蚁」定为「阳茎等颚白蚁」。
- **次异名长表增加对齐回指列（2026-11-05，同一版本，尚未归档发布）**：`dataset/data/isoptera-synonyms.csv` 新增 `localitySource`（`synonym` 逐条对应本异名 / `checklist` 未逐条对齐、整串见主表 `synonymLocalities` 列 / `none` 原数据无模式产地）与 `localityCounts`（`names=N;localities=M`）两列，把「未逐条对齐」与「原数据缺产地」区分开；`dataset/datapackage.json` 字段说明、`dataset/README.md` 构建提示与归档包 `downloads/isoptera-checklist-v2026.10.30.zip` 同步重建。

- 数据补录（初版：只补异名对应关系，不改名录主体与计数；这 3 对随后于同日正式合并，见本条末）：按 GBIF Backbone、Catalogue of Life、Blattodea Species File 的对照结果，把 3 对**可以确定**的异名写入接受名的「次异名」一节（front matter 的 `authority_synonym_*` 字段，正文生成「依外部权威库补录的异名」小节，检索可按异名命中）：
  - *Amitermes californicus* → *Amitermes wheeleri*（GBIF、CoL、BSF 一致视为异名）
  - *Coptotermes guizhouensis* → *Coptotermes formosanus*（CoL、BSF 一致；GBIF 仍标接受名）
  - *Nasutitermes dasyopsis* → *Nasutitermes nigriceps*（CoL、BSF 一致；GBIF 仍标接受名）
  - 初版 `synonym_count` / `synonyms` 仍按原始文献口径，归档数据集的次异名表（696 条）不变；随后按人工判断把这 3 对正式合并（见本条末「异名正式合并」）。
- 命名差异看板改为「逐对判定关系与方向」：19 条名称差异 → 15 对；关系上 异名 4 对 / 组合差异（同种异属）11 对；方向上 外部库名为接收名 3 对 / 本站名为接收名 6 对 / 待定 6 对；可补录 3 对、已补录 3 对（正式合并 3 对后的最终数字见本条末）。物种页「其他数据库」区块与 `search-index.json` 同步。
- 修复：命名差异页的异名/接受名外链曾把 `_config.yml` 的行尾注释拼进 URL（链接失效、破坏 HTML），已修复，并在 `_tools/check_site.py` 增加坏 URL 与归并一致性校验。
- 命名差异看板新增人工核对备注（`_data/name_issue_reviews.json`）：4 条模糊匹配经查为外部库拼写变体或误配——*Cortaritermes silvestrii*（GBIF / BSF 作 *silvestri*）、*Niuginitermes variratae*（BSF / CoL / GBIF 作 *variatae*）、*Euhamitermes chhotanii*（GBIF 作 *chhotannii*）与 *Incisitermes mariae*（GBIF 未收录该新名，模糊匹配到另一有效种 *I. marianus*）——本站名与原始描述一致，不改名；看板与 CSV 标「已人工核对」并附判定依据，规则见 `_tools/外部权威库与一致性核对.md` 第 4.3 节。
- 归档文件：`downloads/isoptera-checklist-v2026.10.30.zip`（本版数据表按本条末的异名合并重新生成，元数据、版本号与 `data/isoptera-taxonomy.json` 的名称/版本随之更新）。
- DOI：本版尚未在 Zenodo 发布，版本 DOI 仍为 2026.10.17 版的 10.5281/zenodo.23646836；发布新版后回填。
- 说明：本版本为纯汇编与对照记录，不构成任何命名行为（no nomenclatural act）。
- **异名正式合并（同日修订）**：3 对「已补录」异名由「另立记录」改为正式并入接受名——
  - 删除异名物种页（`amitermes-californicus`、`coptotermes-guizhouensis`、`nasutitermes-dasyopsis`），并从三语名录、`isoptera-data.json`、`data/` 结构化数据、检索索引、sitemap 与归档数据集中移除；
  - 命名人与模式产地并入接受名的次异名列表（`synonyms` / `synonym_localities`），`synonym_count` 各加 1；`authority_synonym_*`（「依外部权威库补录的异名」）字段随之删除，物种页不再出现「另有独立记录、待合并」的提示；
  - *Amitermes californicus* → *A. wheeleri*（GBIF / CoL / BSF 一致）、*Coptotermes guizhouensis* → *C. formosanus*（CoL / BSF 一致；GBIF 仍标接受名）、*Nasutitermes dasyopsis* → *N. nigriceps*（CoL / BSF 一致；GBIF 仍标接受名）；
  - 计数调整：3071 → 3068 条记录（3008 → 3005 种，63 亚种不变）；白蚁科 2132 → 2130 种、异白蚁科 230 → 229 种、弓白蚁亚科 194 → 193 种、象白蚁亚科 608 → 607 种、弓白蚁属 113 → 112 种、乳白蚁属 59 → 58 种、象白蚁属 243 → 242 种；归档次异名表 696 → 699 条；
  - 外部库缓存同步：`_data/authority_links.json`、`_data/bsf_links.json`（含人工核对工作表）、`downloads/isoptera-authority-crossref.csv` 都按新名录重算；`_data/species_photos.json` 把 *A. californicus* 的照片并入 *A. wheeleri*，`_data/occurrence_summary.json` 与种级 GeoJSON 移除已删物种；命名差异看板减少 7 条（307 → 300 条；名称差异 19 → 12 条、逐对 15 → 12 对；已补录 3 → 0）；
  - 归档文件 `downloads/isoptera-checklist-v2026.10.30.zip` 重新生成（沿用同一版本号；本版尚未在 Zenodo 发布）。

- **名称修订（同日第二次修订）**：对人工复核确认的 4 对名称差异，按外部权威库的接受名改正本站记录（改后这些名字不再出现在命名差异看板）——
  - *Velocitermes aporeticus* → *Diversitermes aporeticus*（并入歧白蚁属，中文名改「怀疑歧白蚁」；GBIF 接受组合）
  - *Parvitermes mexicanus* → *Nasutitermes mexicanus*（并入象白蚁属，中文名改「墨西哥象白蚁」；GBIF 接受组合）
  - *Parvitermes bacchanalis* → *Obtusitermes bacchanalis*（并入钝白蚁属，中文名改「酒神钝白蚁」；Catalogue of Life 接受组合）
  - *Pericapritermes metatus* → 亚种 *Pericapritermes appellans metata* Silvestri, 1914（Catalogue of Life；原种级记录改为 *P. appellans* 下的亚种，中文名「丈量亚种」，模式产地 Guinea: Camayenne; Kakoulima; Kindia 保留）
  - 计数：种 3005 → 3004、亚种 63 → 64（分类单元记录仍 3068 条）；白蚁科 2130 → 2129 种、49 → 50 亚种；瘤白蚁亚科 133 → 132 种、2 → 3 亚种；属级：*Velocitermes* 10 → 9、*Diversitermes* 3 → 4、*Parvitermes* 13 → 11、*Nasutitermes* 242 → 243、*Obtusitermes* 3 → 4、*Pericapritermes* 41 → 40 种（亚种 2 → 3）；旧组合不写入次异名（次异名表仍 699 条）。
  - 外部数据与派生产物同步：`_data/authority_links.json` / `_data/bsf_links.json`（BSF 抽查 20/20）、`downloads/isoptera-authority-crossref.csv`、`_tools/bsf对照/工作表.csv`、`_data/species_photos.json`、`_data/occurrence_summary.json` 与种级 GeoJSON（改名并更新属性）、三语名录、`isoptera-data.json`、`data/` 结构化数据、检索索引、sitemap 与归档数据集。
  - 归档文件 `downloads/isoptera-checklist-v2026.10.30.zip` 重新生成（沿用同一版本号；本版尚未在 Zenodo 发布）。

- **名称修订（同日第三次修订）**：对人工复核确认的 1 项组合差异按外部权威库的接受名改正本站记录（改后该名字不再出现在命名差异看板）——
  - *Megagnathotermes katangensis* → *Polyspathotermes katangensis*（并入多铲白蚁属，中文名改「加丹加多铲白蚁」；Catalogue of Life 与 BSF 均接受该组合，GBIF Backbone 尚未收录、只匹配到多铲白蚁属）；旧组合不写入次异名（次异名表仍 699 条）。
  - 计数：种 3004、亚种 64、分类单元记录 3068 均不变；属级 *Megagnathotermes* 2 → 1 种、*Polyspathotermes* 7 → 8 种；方白蚁亚科 142 种、白蚁科 2129 种不变。
  - 人工核对备注：*Ruptitermes franciscoi* 与 *Anoplotermes franciscoi* 经查是同一物种的两套组合（Acioli & Constantino, 2015, Zootaxa 4032: 451–492 的新组合；Constantino 的 Termite Database 2025-05 版同此），GBIF 的「(Snyder, 1946)」为 Plazi / Zootaxa 题名元数据笔误（正文与图注均作 1959）；本站名不改，结论写入 `_data/name_issue_reviews.json`（看板标「已人工核对」，人工核对条目 4 → 5）。
  - 外部数据与派生产物同步：`_data/authority_links.json` / `_data/bsf_links.json`（BSF 抽查 20/20）、`downloads/isoptera-authority-crossref.csv`、`_tools/bsf对照/工作表.csv`、`_data/species_photos.json`、`_data/occurrence_summary.json` 与分布图（改名后 GBIF Backbone 无对应种，该种级地图移除；同时补上 *Obtusitermes bacchanalis* 的种级地图，种级地图仍 1,180 个、记录仍 87,075 条）、三语名录、`isoptera-data.json`、`data/` 结构化数据、检索索引、sitemap 与归档数据集。
  - 归档文件 `downloads/isoptera-checklist-v2026.10.30.zip` 重新生成（沿用同一版本号；本版尚未在 Zenodo 发布）。

- **新增「白蚁基础知识」页（同版本）**：新建三语基础页，先把形态学的器官与部位做进去——《中国动物志·昆虫纲·第十七卷·等翅目》《白蚁学》《白蚁生物学：现代研究合集》与 Krishna 等（2013）《Treatise on the Isoptera》的术语，按品级、头部、胸部与翅足、腹部、兵蚁、内部器官分组，逐条给出中文正名、拉丁/英文名与识别要点，并附「用这些术语读检索表」的十步速查与异名对照；不改名录数据与计数。
  - 导航：`_layouts/default.html` 主导航在「名录索引」之后加「基础知识」（`nav_basics`，zh 基础知识 / en Basics / es Fundamentos）；三语首页「页面导航」各加一条入口。
  - 检索表：`_includes/fauna-keys.html` 的说明段末加一句术语指引，按页面语言链到对应语种的《白蚁基础知识》。
  - 结构（2026-11-05，同一版本）：`basics.md` 迁为 `basics/morphology.md`（`/basics/morphology/`，`en/basics/morphology.md`、`es/basics/morphology.md` 同步），`/basics/` 改为索引页（`basics/index.md`），分「形态篇」「生物学篇」两个入口，附阅读顺序与分类口径说明；三语首页卡片文案与 `README.md` 页面表同步改写，形态篇的「后续将补充」预告改为指向生物学篇。
  - 新增「生物学篇」`basics/biology.md`（`/basics/biology/`，当前仅中文）：品级与发育、筑巢、食性与消化共生、生活史与群体建立、社会行为与巢内通讯、防御与天敌、生态功能与人类关系七章，附「与旧文献的几处差异」（巢的空调模型、东门中心仿生叙事、甲烷估计、菌食起源时间、科级归属）与 11 条文献；英文与西班牙文版同步（`en/basics/biology.md`、`es/basics/biology.md`）。
- **检索表（同版本）**：木白蚁科页新增 Krishna 等（2013）《Treatise on the Isoptera of the World》第 75—78 页的世界分属检索表，有翅成虫 18 组 19 个终点、兵蚁 20 组 21 个终点，接在《中国动物志》兵蚁表（5 属）之后；化石属 †Proelectrotermes、†Electrotermes 仅列名不链接，原表未含的 Longicaputermes、Roisinitermes 在表前说明。
  - 生成：`_tools/fauna/keys/keys_orders.py` 新增 KALO_WORLD 与 KALOSRC；`_tools/fauna/keys/emit.py` 支持用 `+` 合并终点、用 `|` 附注、用 `fos:` 标记化石属；`_data/fauna_keys.json` 重生成后该科 3 表 42 组 45 个终点。
  - 渲染：`_includes/fauna-keys.html` 增加 Treatise 来源说明与引文，化石属与合并终点按新结构输出；不改名录数据与计数。
- **检索表收缩与属级描述占位（2026-11-07，同一版本）**：撤下全部据《中国动物志》编制的科 / 属 / 种检索表；`_data/fauna_keys.json` 只保留 `/list/`（Hellemans 等 2024 目级表）、`/family/termitidae/`（Hellemans 等 2024 白蚁科亚科表）与 `/family/kalotermitidae/`（Krishna 等 2013 木白蚁科世界分属表）三页。新增 `_data/genus_sources.json`：据 Krishna 等（2013）整理 326 个属的原始描述出处、模式种与文献线索；`_includes/genus-morphology.html` 在尚无《中国动物志》属级描述的 291 个属页显示「待补」占位与文献线索，不代写描述。补写清单见 `_reports/genus-morphology-worklist.md` / `.csv`。不改名录数据与计数。
- **属级描述正文与物种占位（2026-11-07，同一版本）**：新增 `_data/morphology_genera.json` 与 `_tools/fauna/morphology/descriptions/*.json`，首批 152 个属据原始发表或修订文献改写为分品级中文描述（Krishna 1961 木白蚁科、Sands 1972 非洲无兵蚁类、Sands 1965 东非 Nasutitermitinae、Holmgren 1912、Emerson 1959、Constantino 1999、Roisin & Bourguignon 2011 等）；`_includes/genus-morphology.html` 优先渲染改写稿，无稿才显示占位。物种 / 亚种页由 `_includes/species-morphology.html` 统一挂载：有 `_data/morphology_species.json` 条目则渲染，已有《中国动物志》记载则不重复，其余显示三语待补说明并链接属页；单型属首批 20 种据属级描述生成并注明。属、种两级补写清单见 `_reports/genus-morphology-worklist.{md,csv}` 与 `_reports/species-morphology-worklist.{md,csv}`。不改名录数据与计数。
- **派生（同版本）**：`sitemap.txt` 重算（3786 个 URL；696 个页面，含 3089 个物种页），`_data/changelog.json` 与 `changelog.atom` 随本条目重建。

## 2026.10.17 — 首个 DOI 归档版本 First archived release

- 数据内容与项目网站 2026.10.17 正式版一致：13 科、18 亚科、323 属、3008 种、63 亚种（3071 条记录）。
- 归档文件：
  - `data/isoptera-checklist.csv`：逐条分类单元表，22 列（含中文正名、模式产地、分布中英、次异名、页面链接）。
  - `data/isoptera-taxonomy.json`：完整分类树，含各级计数与页面链接。
  - `data/isoptera-synonyms.csv`：次异名长表（含与模式产地的对应状态 localityAlignment）。
  - `data/isoptera-counts.csv`：科/亚科级计数。
  - `data/isoptera-references.csv`：77 条参考文献（带 DOI 者随条目给出）。
  - `datapackage.json`：Frictionless Data Package 描述（含字段字典）。
  - `datacite-metadata.xml`：DataCite Metadata Schema 4.6 记录。
- 许可：CC BY 4.0。
- 归档 DOI（2026-10-25 于 Zenodo 发布）：版本 DOI [10.5281/zenodo.23646836](https://doi.org/10.5281/zenodo.23646836)；概念 DOI（全部版本，始终指向最新版）[10.5281/zenodo.23646835](https://doi.org/10.5281/zenodo.23646835)。
- 说明：本版本为纯汇编，不构成任何命名行为（no nomenclatural act）。
